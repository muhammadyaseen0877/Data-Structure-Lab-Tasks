#include <iostream>
using namespace std;

class BankAccount{
    private:
    float balance;
    
    public:
    BankAccount(){
        balance=0.0;
    }
    
    BankAccount(float deposit){
        balance+=deposit;
    }
    
    void withdraw(float amount){
        if(balance<amount){
            cout<<"No insufficient funds..."<<endl;
        }
        else{
            balance-=amount;
        }
    }
    
    BankAccount(const BankAccount &other){
    this->balance= other.balance;
    }
    
    void showbalance(){
        cout<<"the balance = $ "<<balance<<endl;
    }

};

int main(){
	BankAccount account1;
	cout<<"account #1: ";
	account1.showbalance();
	
	BankAccount account2(1000);
		cout<<"account #2: ";
	account2.showbalance();
	
	BankAccount account3(account2);
		cout<<"account #3: ";
	account3.showbalance();
	
	account3.withdraw(200);
	cout<<"account #3 after withdraw: ";
	account3.showbalance();

	
	cout<<"account #2: ";
	account2.showbalance();
		
	return 0;
}
