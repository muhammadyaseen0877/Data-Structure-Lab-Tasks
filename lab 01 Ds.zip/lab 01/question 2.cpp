#include <iostream>
#include <cstring>
using namespace std;

class Exam{
	char* StdName;
	char* date;
	int* Score;
	
	public:
		Exam(char* name, char* dat, int marks){
			StdName= new char[strlen(name)+1];
			strcpy(Stdname, name);
			
			date=new char[strlen(dat)+1];
			strcpy(date,dat);
			
			score=new int(marks);
		}
		
	void setname(char* name){
		delete[] StdName;
		StdName= new char[strlen(name)+1];
		strcpy(Stdname, name);
		
	}
	
	void setdate(char* dat){
		delete[] date;
		date=new char[strlen(dat)+1];
			strcpy(date,dat);
	
	}
	
	void setNewScore(int marks){
		delete Score;
		*score=marks;
	}
	
	~Exam(){
		delete[] StdName;
		delete[] date;
		delete Score;
	}
	
	void showData(){
		cout<<"Student name: "<<*StdName<<endl;
		cout<<"Date: "<<*date<<endl;
		cout<<"Score: "<<score<<endl;
	}
	Exam(const Exam& other){
		StdName= new char[strlen(other.StdName)+1];
		strcpy(Stdname, other.StdName);
		
		date=new char[strlen(other.date)+1];
			strcpy(date,other.date);
			
		Score= new int(*other.Score);
		
	}
	
	Exam& operator=(const Exam& other){
		if(this != &other){
		delete[] StdName;
		delete[] date;
		delete Score;
		
		StdName= new char[strlen(other.StdName)+1];
		strcpy(Stdname, other.StdName);
		
		date=new char[strlen(other.date)+1];
			strcpy(date,other.date);
			
		Score= new int(*other.Score);
			
		}
		return *this;
	}
};

	int main(){
		Exam E1("Yaseen", "25-8-2025", 68);
		E1.showData();
		
		Exam E2=E1;
		E2.showData();
		
		E2=Exam("Ali", "11-06-2025", 70);
		E2.showData();
		
		
	}
